from hardware.remotes.lirc import LircRemote

class LircIRDevice:
	def __init__(self, type, conf_name, output_pin, name):
		self._remote = LircRemote(conf_name, output_pin)
		self.type = type
		self.conf = conf_name
