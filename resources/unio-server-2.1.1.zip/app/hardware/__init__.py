from .controllers import DeviceManager

deviceManager = DeviceManager()

class Hardware():
	def init_app(self, app):
		deviceManager.init(app)

hardware = Hardware()