
def string_inverse(str):
	return str[::-1]

def bit_inverse(str):
	return ''.join('1' if bit == '0' else '0' for bit in str)

def convert_hex_to_binary_string(hex_str):
	hex_str = hex_str.replace('0x','')
	return bin(int(hex_str, 16))[2:].rjust(len(hex_str)*4, '0')

def convert_int_to_binary_string(hex):
	return bin(hex)[2:]#.rjust(len(hex_str)*4, '0')

def convert_binary_string_to_hex(bin_str):
	"{0:0>4X}".format(int(bin_str, 2))

def count_ones(bin_str):
	return bin_str.count('1')